<div class="page-topbar">
    <div class="logo-area"></div>
    <div class="quick-area">
        <div class="pull-left">
            <ul class="info-menu left-links list-inline list-unstyled">
                <li class="sidebar-toggle-wrap">
                    <a href="#" data-toggle="sidebar" class="sidebar_toggle">
                        <i class="fa fa-bars"></i>
                    </a>
                </li>
            </ul>
        </div>
        <div class='pull-right'>
            <ul class="info-menu right-links list-inline list-unstyled">
                <li class="profile">
                    <a href="#" data-toggle="dropdown" class="toggle">
                        <?php
                        $id = $_SESSION['id'];
                        $query = "SELECT * FROM users WHERE id = $id";
                        $run = mysqli_query($con, $query);
                        while ($row = mysqli_fetch_assoc($run)) {
                            $name = $row['name'];
                            $profile = $row['profile'];
                        }
                        ?>
                        <img src="<?php if(empty($profile) || $profile == "") { echo "assets/data/icons/default-avatar.png"; } else { echo "assets/uploads/".$profile; } ?>" style="max-width:100px" alt="<?php echo $name; ?>" alt="user-image" class="img-circle img-inline">
                        <span><?php echo $name; ?> <i class="fa fa-angle-down"></i></span>
                    </a>
                    <ul class="dropdown-menu profile animated fadeIn">
                        <li><a href="page.php?view=profile"><i class="fa fa-user"></i> Profile</a></li>
                        <li><a href="page.php?view=settings"><i class="fa fa-wrench"></i> Settings</a></li>
                        <li><a href="logout.php"><i class="fa fa-lock"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>

</div>