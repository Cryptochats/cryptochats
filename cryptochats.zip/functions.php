<?php

/*
 * This is simple function which return the file name from url.
 * @author rizimore
 * @version 1.0.0 
 */
function get_file_name() {
	return basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
}

/*
 * Show the alert for some seconds and dismiss.
 * @author rizimore
 * @version 1.0.0 
 */
function alert($message, $status){
    echo "<div class='alert alert-$status alert-dismissible fade in'>
                <button type='button' class='close' data-dismiss='alert' aria-label='close'><span aria-hidden='true'>×</span></button>
                $message
        	</div>";
}

/*
 * Include some important files.
 * @author rizimore
 * @version 1.0.0 
 */
include 'config/database.php';