<?php

// $con = mysqli_connect("localhost", "root", "", "crypto");
$con = mysqli_connect("localhost", "wwwcrypt_rizimor", "rizimore,,,", "wwwcrypt_rizimore");

if(!$con) {
	alert("Database connection problem.", "danger");
}