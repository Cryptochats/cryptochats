<script src="assets/js/jquery-1.11.2.min.js"></script>
<script src="assets/js/jquery.easing.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/plugins/pace/pace.min.js"></script>
<script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="assets/plugins/viewport/viewportchecker.js"></script>
<script>
    window.jQuery || document.write('<script src="assets/js/jquery-1.11.2.min.js"><\/script>');
</script>


<script src="assets/plugins/echarts/echarts-custom-for-dashboard.js"></script>
<script src="assets/plugins/flot-chart/jquery.flot.js"></script>
<script src="assets/plugins/flot-chart/jquery.flot.time.js"></script>
<script src="assets/js/chart-flot.js"></script>
<script src="assets/plugins/morris-chart/js/raphael-min.js"></script>
<script src="assets/plugins/morris-chart/js/morris.min.js"></script>
<script src="assets/js/chart-morris.js"></script>

<!-- Users -->
<script src="assets/plugins/realtimepricing/libs/dataTables/datatables.min.js"></script>
<script>
	$(document).ready(function(){
	    $('#table').DataTable();
	});
</script>

<script src="assets/js/scripts.js"></script>