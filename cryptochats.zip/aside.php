<div class="page-sidebar fixedscroll">
    <div class="page-sidebar-wrapper" id="main-menu-wrapper">

        <ul class='wraplist'>
            <li class='menusection'>Main</li>
            <li><a href="page.php?view=dashboard"><i class="fa fa-th-large"></i><span class="title">Dashboard</span></a></li>
            <li><a href="page.php?view=buy"><i class="fa fa-credit-card"></i><span class="title">Buy Tokens</span></a></li>
            <li><a href="page.php?view=transactions"><i class="fa fa-sitemap"></i><span class="title">Transactions</span></a></li>
            <li><a href="page.php?view=wallet"><i class="img"><img src="assets/data/icons/wallet-o.png" style="width:16px"></i><span class="title">My Wallet</span></a></li>
            
            <?php
            $id = $_SESSION['id'];
            $query = "SELECT * FROM users WHERE role = 'admin' AND id = $id";
            $run = mysqli_query($con, $query);
            $count = mysqli_num_rows($run);
            if ($count == 1) {
            ?>

            <li class='menusection'>Admin</li>
            <li><a href="page.php?view=users"><i class="fa fa-users"></i><span class="title">Users</span></a></li>
            <li>
                <a href="page.php?view=cryptochats"><i class="img"><img src="assets/data/icons/coins.png" style="width:16px"></i><span class="title">Cryptochats</span></a>
            </li>

            <?php } ?>

            <li class='menusection'>Settings</li>
            <li><a href="page.php?view=settings"><i class="fa fa-gear"></i><span class="title">Settings</span></a></li>
            <li><a href="page.php?view=security"><i class="fa fa-lock"></i><span class="title">Security</span></a></li>

            <li class='menusection'>Suport</li>
            <li><a href="page.php?view=contact"><i class="fa fa-envelope"></i><span class="title">Contact Us</span></a></li>
            <li><a href="page.php?view=faqs"><i class="fa fa-question-circle"></i><span class="title">FAQ's</span></a></li>
        </ul>
    </div>
</div>