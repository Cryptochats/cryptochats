<?php

/*
 * Name: page.php
 * Description: This page handle all the pages like router.
 * @author rizimore
 * @version 1.0
 */
$title = "Dashboard - Cryptochats";
include "header.php";
include "nav.php";

if (!isset($_SESSION['id'])) {
	header("Location: login.php");
}

?>

<div class="page-container row-fluid container-fluid">

	<?php include "aside.php"; ?>

	<?php

	if (isset($_GET['view'])) {
		
		$view = $_GET['view'];

		if($view == "dashboard") {
			include "templates/dashboard/pages/dashboard.php";
		}
		if($view == "settings") {
			include "templates/dashboard/pages/settings.php";
		}
		if($view == "security") {
			include "templates/dashboard/pages/security.php";
		}
		if($view == "buy") {
			include "templates/dashboard/pages/buy.php";
		}
		if($view == "transactions") {
			include "templates/dashboard/pages/transactions.php";
		}
		if($view == "wallet") {
			include "templates/dashboard/pages/wallet.php";
		}
		if($view == "users") {
			include "templates/dashboard/pages/users.php";
		}
		if($view == "cryptochats") {
			include "templates/dashboard/pages/cryptochats.php";
		}
	}

	?>

</div>

<?php
include "footer.php";