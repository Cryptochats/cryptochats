-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2018 at 07:44 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crypto`
--

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE `tokens` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `saleprice` varchar(255) NOT NULL,
  `forsale` varchar(255) NOT NULL,
  `softcap` int(11) NOT NULL,
  `hardcap` int(11) NOT NULL,
  `totalsupply` int(11) NOT NULL,
  `general` int(11) NOT NULL,
  `research` int(11) NOT NULL,
  `ecosystem` int(11) NOT NULL,
  `marketing` int(11) NOT NULL,
  `partnership` int(11) NOT NULL,
  `team` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tokens`
--

INSERT INTO `tokens` (`id`, `name`, `symbol`, `saleprice`, `forsale`, `softcap`, `hardcap`, `totalsupply`, `general`, `research`, `ecosystem`, `marketing`, `partnership`, `team`) VALUES
(1, 'Cryptochats', 'CCX', '0.000125', '417597597.18', 1200000, 18000000, 818818818, 10, 5, 35, 25, 10, 15);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `order_id`, `user`, `address`, `invoice`, `amount`, `token`, `status`, `date`, `action`) VALUES
(27, 88936, 9, '0x527BC583AF494ebfF73dE7c06e403F242E6f7c8D', 'bb9c4f9aa4a038d0a308b8d96f435bbd', '0.0010', '1', 2, '2018-06-29 03:54:26', 'plus'),
(28, 29817, 9, '0xA33279c85f89f8c0270c23d04c0cA00143D8c2Ed', '7148c12721e33899805c863d6e758826', '0.000125', '1', 1, '2018-06-29 04:02:48', 'plus'),
(29, 78190, 9, '0xb5626f6b444c5E1026b71afB1f59b5b0881407f7', 'b84b4a2b8b693a1894e9c23484aac0fe', '0.0025', '20', 1, '2018-06-29 04:07:24', 'plus'),
(30, 52011, 9, '0x070b5AA6669b7e218391dAE5095d80248f57b53c', '0a72bdd797bb3027ba0a10310034db7c', '0.00125', '10', 2, '2018-06-29 04:16:59', 'plus'),
(31, 19213, 11, '0x809EF6E8B2B90743a0c9D8462d2E31996c7b0c7E', 'cf02fe59fca83be7b812d8fced9ea236', '0.00125', '10', 2, '2018-07-01 01:39:25', 'plus'),
(32, 15471, 11, '0x7Cf24199c78Df32Cb70603f079C4A909696D2014', '4741d839e67d382494391b9917afe810', '0.00125', '10', 2, '2018-07-01 22:32:48', 'plus'),
(33, 30710, 11, '0xC0A5b8a007d5345760A362D6bf9Da9a35e0ea08A', '77ea3ed60c6639ba94da73da4b3d34d9', '0.000125', '1', 1, '2018-07-01 22:39:53', 'plus');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `postcode` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `code` varchar(255) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `2fa` tinyint(1) NOT NULL,
  `balance` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `profile`, `address1`, `address2`, `city`, `postcode`, `country`, `dob`, `active`, `role`, `code`, `secret`, `2fa`, `balance`) VALUES
(11, 'Rizi More', 'rizimore@gmail.com', 'rizimore,,,', '1969384_782058408545875_759996333339336868_n.jpg', 'Shahdara, Lahore', '', 'Lahore', '54950', 'Pakistan', '1999-07-28', 1, 'admin', '$2y$10$yXbJmweMN93l4ZKpRUxbXeWrDpJQmgeIZsnseJEzcWX3HOKOkJ5dC', 'UVXA3J2XL7U5PTKZ', 1, '20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tokens`
--
ALTER TABLE `tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
