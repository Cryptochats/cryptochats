<?php

/*
* Import autload file for phpmailer library.
* @author rizimore
* @version 1.0.0 
*/
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$title = "Register - Cryptochats";
include 'header.php';

?>
<div class="container-fluid">
    <div class="login-wrapper row">
        <div id="login" class="login loginpage col-lg-offset-4 col-md-offset-3 col-sm-offset-3 col-xs-offset-0 col-xs-12 col-sm-6 col-lg-4">    
            <div class="login-form-header">
                 <img src="assets/data/icons/signup.png" alt="login-icon" style="max-width:64px">
                 <div class="login-header">
                     <h4 class="bold color-white">Create your account!</h4>
                     <h4><small>Please enter your data to register.</small></h4>
                 </div>
            </div>
           
            <div class="box login">

                <div class="content-body">

                    <form action="register.php" method="post">
                        <div class="row">
                            <div class="col-xs-12">

                                <?php
                                /*
                                 * Register the user into database.
                                 * @author rizimore
                                 * @version 1.0.0 
                                 */
                                if(isset($_POST['submit'])) {
                                    
                                    $name       = $_POST['name'];
                                    $email      = $_POST['email'];
                                    $password   = $_POST['password'];
                                    $key        = password_hash($password, PASSWORD_BCRYPT);

                                    if(strlen($password) < 8) {
                                        alert("Your password is too short. Minimum 8 charectors.", "primary");
                                    }

                                    $query = "SELECT * FROM users WHERE email = '{$email}'";
                                    $run = mysqli_query($con, $query);
                                    $count = mysqli_num_rows($run);
                                    if($count == 0) {

                                        $query = "INSERT INTO users(name, email, password, code) VALUES('{$name}', '{$email}', '{$password}', '{$key}')";
                                        $run = mysqli_query($con, $query);
                                        if($run) {

                                            $mail = new PHPMailer(true);
                                            try {
                                                $mail->SMTPDebug = 0;
                                                $mail->isSMTP();
                                                $mail->Host = 'smtp.gmail.com';
                                                $mail->SMTPAuth = true;
                                                $mail->Username = 'rizimore@gmail.com';
                                                $mail->Password = 'MubashirRasoolRazvi,,,786';
                                                $mail->SMTPSecure = 'tls';
                                                $mail->Port = 587;

                                                $mail->setFrom('rizimore@gmail.com', 'Cryptochats');
                                                $mail->addAddress($email, $name);

                                                $mail->isHTML(true);
                                                $mail->Subject = 'Email Confirmation';
                                                $mail->Body = "<h1>Email Confirmation</h1>
                                                            <p>You simple need to click the below link to activate your account.</p>
                                                            <a href='http://localhost/wallet/login.php?key=$key'>Activate Account</a>";
                                                $mail->AltBody = 'Your browser does not support HTML emails. Please contact our support.';

                                                $mail->send();
                                                alert("Successfully registerd. Check your email for activation.", "success");

                                            } catch (Exception $e) {
                                                echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
                                            }

                                            
                                        }

                                    } else {
                                        alert("This email is already registerd.", "primary");
                                    }

                                }
                                ?>

                                <div class="form-group">
                                    <label class="form-label">Name</label>
                                    <div class="controls">
                                        <input type="text" class="form-control" name="name" placeholder="name" required="required">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Email</label>
                                    <div class="controls">
                                        <input type="email" class="form-control" name="email" placeholder="email" required="required">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Password</label>
                                    <div class="controls">
                                        <input type="password" class="form-control" name="password" placeholder="password" required="required">
                                    </div>
                                </div>

                                <div class="pull-left">
                                    <button class="btn btn-primary mt-10 btn-corner right-15" type="submit" name="submit">Create Account</button>
                                    <a href="login.php" class="btn mt-10 btn-corner signup">Already have an account?</a>
                                </div>

                            </div>
                        </div>
                    </form>

                </div>
            </div>

            <p id="nav">
                <a class="pull-left" href="forgot.php" title="Password Lost and Found">Forgot password?</a>
            </p>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>