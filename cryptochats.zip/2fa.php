<?php

$title = "2FA Authentication - Cryptochats";
include 'header.php';

?>
<div class="container-fluid">
    <div class="login-wrapper row">
        <div id="login" class="login loginpage col-lg-offset-4 col-md-offset-3 col-sm-offset-3 col-xs-offset-0 col-xs-12 col-sm-6 col-lg-4">    
            <div class="login-form-header">
                 <img src="assets/data/icons/padlock.png" alt="login-icon" style="max-width:64px">
                 <div class="login-header">
                     <h4 class="bold color-white">2FA Authentication!</h4>
                     <h4><small>Please enter your 2fa code to login.</small></h4>
                 </div>
            </div>
           
            <div class="box login">

                <div class="content-body">
                    <form action="" method="post">
                        <div class="row">
                            <div class="col-xs-12">
                                
                                <?php
                                require "plugins/2fa.php";
                                $Authenticator = new Authenticator();

                                /*
                                 * Check the 2FA code is correct or no.
                                 * @author rizimore
                                 * @version 1.0.0 
                                 */
                                if (isset($_POST['submit'])) {
                                    
                                    $code = $_POST['code'];
                                    $id = $_GET['id'];

                                    $query = "SELECT * FROM users WHERE id = $id";
                                    $run = mysqli_query($con, $query);
                                    while ($row = mysqli_fetch_assoc($run)) {
                                        $secret = $row['secret'];
                                        $check = $Authenticator->verifyCode($secret, $code, 2);

                                        if ($check) {
                                            $_SESSION['id'] = $id;
                                            header("Location: page.php?view=dashboard");
                                        } else {
                                            alert("Your code is not correct.", "danger");
                                        }
                                    }
                                }
                                ?>

                                <div class="form-group">
                                    <label class="form-label">2FA Code</label>
                                    <div class="controls">
                                        <input type="text" class="form-control" name="code" placeholder="code..." required="required">
                                    </div>
                                </div>

                                <div class="pull-left">
                                    <button class="btn btn-primary mt-10 btn-corner right-15" type="submit" name="submit">Authenticate</button>
                                </div>

                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <p id="nav">
                <a class="pull-left" href="contact.php" title="Password Lost and Found">Dont have longer access to 2FA? Contact Support.</a>
            </p>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>