<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen">
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="assets/plugins/bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
<link href="assets/fonts/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="assets/fonts/webfont/cryptocoins.css" rel="stylesheet" type="text/css">
<link href="assets/css/animate.min.css" rel="stylesheet" type="text/css">
<link href="assets/plugins/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" type="text/css">

<link href="assets/plugins/jvectormap/jquery-jvectormap-2.0.1.css" rel="stylesheet" type="text/css" media="screen">
<link href="assets/plugins/morris-chart/css/morris.css" rel="stylesheet" type="text/css" media="screen">

<!-- Users -->
<link href="assets/plugins/realtimepricing/libs/dataTables/datatables.min.css" rel="stylesheet">

<link href="assets/css/style.css" rel="stylesheet" type="text/css">
<link href="assets/css/responsive.css" rel="stylesheet" type="text/css">