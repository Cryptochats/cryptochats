<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>

        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">
                    <h1 class="title">My Wallet</h1>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
	        <section class="box has-border-left-3">
	                <header class="panel_header">
	                    <h2 class="title pull-left">Cryptochats wallet</h2>
	                </header>
	                <div class="content-body">    
	                    <div class="row">
	                        <div class="col-xs-12">
	                            <div class="text-center no-mt no-mb">
	                                <div class="transfer-wraper">
	                                    <div class="crypto-icon">
	                                        <i class="cc BTC color-primary"></i>
	                                    </div>
	                                    <strong class="mb-20">Cryptochats</strong>
	                                    <div class="form-group cryptonia no-mb">
	                                        <label class="form-label mt-10">wallet address</label>
	                                        <div class="input-group mb-10">
	                                            <span class="input-group-addon has-gradient-to-right-bottom">
	                                                <i class="cc BTC-alt icon-white"></i>   
	                                            </span>
	                                            <p class="form-control-static with-border">OxsD12F32xvW3deG5...</p>
	                                        </div>

	                                        <span class="desc">1 BTC</span>
	                                        <label class="form-label"> = 12.734 USD</label><br>
	                                        
	                                        <span class="desc">Total selling amount</span>
	                                        <label class="form-label">54,634 $</label><br>
	                                        
	                                        <span class="desc">Total buying buy</span>
	                                        <label class="form-label">534,263 $</label><br>

	                                        <div class="mt-10 balance">
	                                            <strong class="form-label bold">Balance : </strong>
	                                            <span class="desc color-primary f-s-14"> 1.5238237 BTC</span>
	                                        </div>
	                                        <div class="balance bg-white">
	                                            <strong class="form-label bold">Balance in USD: </strong>
	                                            <span class="desc color-primary f-s-14"> 15,238,237 USD</span>
	                                        </div>

	                                        <div class="col-sm-6 no-pl">
	                                            <a href="buy-and-sell.html" class="btn btn-primary btn-lg mt-20 has-gradient-to-right-bottom" style="width:100%">Withdraw</a>
	                                        </div>
	                                        <div class="col-sm-6 no-pr">
	                                            <a href="buy-and-sell.html" class="btn btn-primary btn-lg mt-20 has-gradient-to-right-bottom" style="width:100%">Deposit</a>
	                                        </div>
	                                        
	                                    </div>
	                                       
	                                    
	                                </div>
	                               
	                            </div>
	                        </div>
	                       
	                    </div>
	                </div>
	        </section>
	    </div>
    </div>
</section>