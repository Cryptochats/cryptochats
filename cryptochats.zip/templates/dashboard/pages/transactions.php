<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>

        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">
                    <h1 class="title">Transactions</h1>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <section class="box" style="border-left: 3px solid #e77512;">
                <header class="panel_header">
                    <h2 class="title pull-left">Recent transactions</h2>
                </header>
                <div class="content-body">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="table-responsive" data-pattern="priority-columns">
                                <table class="table table-small-font no-mb" id="table">
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Time</th>
                                            <th>Status</th>
                                            <th>Activity</th>
                                            <th>Invoice</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $id = $_SESSION['id'];
                                        $query = "SELECT * FROM transactions WHERE user = $id ORDER BY id DESC";
                                        $run = mysqli_query($con, $query);
                                        while ($row = mysqli_fetch_assoc($run)) {
                                            $order      = $row['id'];
                                            $order_id   = $row['order_id'];
                                            $address    = $row['address'];
                                            $datetime   = $row['date'];
                                            $amount     = $row['amount'];
                                            $status     = $row['status'];
                                            $action     = $row['action'];
                                        ?>
                                        <tr>
                                            <th>
                                                <i class="<?php 
                                                            if($status == 0) { echo "fa fa-dot-circle-o cancelled"; }
                                                            if($status == 1) { echo "fa fa-dot-circle-o pending"; }
                                                            if($status == 2) { echo "fa fa-dot-circle-o complete"; }
                                                            ?>">
                                                </i> Order number <?php echo $order; ?>
                                            </th>
                                            <td><?php echo $datetime; ?></td>
                                            <?php 
                                            if($status == 0) { echo '<td><span class="status-cancelled">cancelled</span></td>'; }
                                            if($status == 1) { echo '<td><span class="status-pending">pending</span></td>'; }
                                            if($status == 2) { echo '<td><span class="status-complete">complete</span></td>'; }
                                            ?>
                                            <td><?php if($action == "plus") { ?><i class="fa fa-plus complete normal"></i><?php } ?><?php echo $amount; ?></td>
                                            <td><a href="http://localhost/wallet/page.php?view=buy&id=<?php echo $order_id; ?>" class="btn btn-primary btn-corner">view invoice</a></td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</section>