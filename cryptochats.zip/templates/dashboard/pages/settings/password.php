<?php
/*
 * Change the password of user from profile section.
 * @author rizimore
 * @version 1.0.0 
 */
if (isset($_POST['change'])) {
	$password = $_POST['password'];
	$confirm  = $_POST['confirm'];

	if (strlen($password) < 8) {
		alert("Your passowrd is too short. At least 8 charectors.", "danger");
	} else if($password != $confirm) {
		alert("Your password does not match.", "danger");
	} else {
		$id = $_SESSION['id'];
		$query = "UPDATE users SET password = '{$password}' WHERE id = $id";
		$run = mysqli_query($con, $query);
		if($run) {
			alert("Your password successfuly updated.", "success");
		}
	}
}
?>
<section class="box has-border-left-3">
    <header class="panel_header"><h2 class="title pull-left">Change Password</h2></header>
    <div class="content-body">    
        <div class="row">
            <div class="form-container">
                <form action="" method="post">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="col-lg-6 no-pl">
                                <div class="form-group">
                                    <label class="form-label">Password</label>
                                    <div class="controls">
                                        <input type="password" class="form-control" name="password">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 no-pr">
                                <div class="form-group">
                                    <label class="form-label">Confirm Password</label>
                                    <div class="controls">
                                        <input type="password" class="form-control" name="confirm">
                                    </div>
                                </div>
                            </div>
                            <div class="pull-left">
                                <h4><i class="fa fa-info-circle color-primary complete f-s-14"></i><small>Note that password must be at lest 7 characters long.</small></h4>
                            </div>
                            <div class="pull-right">
                                <button type="submit" class="btn btn-primary btn-corner" name="change"> Change Password</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
	</div>
</section>