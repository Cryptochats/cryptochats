<section class="box has-border-left-3">
    <header class="panel_header"><h2 class="title pull-left">2FA Authentication</h2></header>
    <div class="content-body">    
        <div class="row">
        	<div class="col-xs-12">
        		<?php
        		$id = $_SESSION['id'];
        		$query = "SELECT * FROM users WHERE id = $id AND 2fa = 1";
        		$run = mysqli_query($con, $query);
        		$count = mysqli_num_rows($run);
        		if($count == 1) {
        		?>

        		<p>Your 2fa authentication is enable right now. You can disable it anytime as you want.</p>
            	<form action="" method="post">
	            	<div class="pull-right">
	            		<?php
	            		/*
						 * Deactivate the 2FA authentication.
						 * @author rizimore
						 * @version 1.0.0 
						 */
	            		if(isset($_POST['2fa-deactivate'])) {
	            			$id = $_SESSION['id'];
	            			$query = "UPDATE users SET 2fa = 0 WHERE id = $id";
	            			$run = mysqli_query($con, $query);
	            			if($run) {
	            				header("Location: page.php?view=settings&2fa=deactivate");
	            			}
	            		}
	            		?>
	                    <button type="submit" class="btn btn-primary btn-corner" name="2fa-deactivate"> Deactivate 2FA</button>
	                </div>
                </form>

        		<?php } else { ?>
            	
            	<p>If you want to enable the two way authentication please click the enable button.</p>
            	<div class="pull-right">
                    <button type="button" class="btn btn-primary btn-corner" data-toggle="modal" href="#2fa"> Enable 2FA</button>
                </div>
            	
            	<?php } ?>
			</div>
        </div>
	</div>
</section>

<div class="modal fade col-xs-12" id="2fa" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog animated fadeInDown">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Authentication Settings</h4>
            </div>
            <div class="modal-body">
	            <form action="" method="post">
	            	<?php
			    	require "plugins/2fa.php";
			    	$Authenticator = new Authenticator();

			    	/*
					 * Generating secret key.
					 * @author rizimore
					 * @version 1.0.0 
					 */
			    	$id = $_SESSION['id'];
			    	$query = "SELECT * FROM users WHERE id = $id";
			    	$run = mysqli_query($con, $query);
			    	while($row = mysqli_fetch_assoc($run)) {
			    		$secret = $row['secret'];
			    		if ($secret == "" || empty($secret)) {
			    			$secretkey = $Authenticator->generateRandomSecret();
			    			$query = "UPDATE users SET secret = '{$secretkey}' WHERE id = $id";
			    			$run = mysqli_query($con, $query);
			    		}
			    	}

			    	/*
					 * Check the 2FA code is correct or no.
					 * @author rizimore
					 * @version 1.0.0 
					 */
					if (isset($_POST['2fa'])) {
						
						$code = $_POST['code'];
						$id = $_SESSION['id'];

						$query = "SELECT * FROM users WHERE id = $id";
						$run = mysqli_query($con, $query);
						while ($row = mysqli_fetch_assoc($run)) {
							$secret = $row['secret'];
							$check = $Authenticator->verifyCode($secret, $code, 2);

							if ($check) {
								$id = $_SESSION['id'];
								$query = "UPDATE users SET 2fa = 1 WHERE id = $id";
								$run = mysqli_query($con, $query);
								if($run) {
									header("Location: page.php?view=settings&2fa=success");
								}
							} else {
								header("Location: page.php?view=settings&2fa=error");
							}
						}
					}
			    	?>

			    	<div class="row">
			    		<div class="col-md-4">
			    			<?php
			            	/*
							 * Generate the QR image url using secret key.
							 * @author rizimore
							 * @version 1.0.0 
							 */
			            	$query = "SELECT * FROM users WHERE id = $id";
			            	$run = mysqli_query($con, $query);
			            	while ($row = mysqli_fetch_assoc($run)) {
			            		$secret = $row['secret'];
			            		$url = $Authenticator->getQR('Cryptochats', $secret);
			            	?>
			                <img src="<?php echo $url; ?>" class="img-responsive" alt="2fa authentication">
			                <?php } ?>
			    		</div>
			    		<div class="col-md-8">
			    			<h4><small><b>Securit key :</b></small> <?php echo $secret; ?></h4>
		                    <input type="text" class="form-control" name="code" placeholder="enter the 2fa code here ...">
			    		</div>
			    	</div>

	            </div>
	            <div class="modal-footer">
	                <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
	                <button type="submit" class="btn btn-primary" name="2fa"><i class="fa fa-check"></i> Authenticate</button>
	            </div>
            </form>
        </div>
    </div>
</div>