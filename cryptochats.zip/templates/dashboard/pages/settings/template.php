<?php
/*
 * Showing errors.
 * @author rizimore
 * @version 1.0.0 
 */
if (isset($_GET['error'])) {
    $error = $_GET['error'];
    
    echo "<div class='col-lg-12'>";

    if($error == "type") {
        alert("File type does not allowed. Please use JPG, PNG or GIF.", "primary");
    }

    if ($error == "size") {
        alert("File sixe is greater than 2MB.", "primary");
    }

    if ($error == "none") {
        echo "<div class='col-lg-12'>";
        alert("Your profile successfuly updated.", "success");
    }
    echo "</div>";
}

if (isset($_GET['2fa'])) {
    $error = $_GET['2fa'];
    
    echo "<div class='col-lg-12'>";

    if($error == "error") {
        alert("Your code is not correct please try again.", "danger");
    }

    if ($error == "success") {
        alert("Your 2fa authentication susscessfully enabled.", "success");
    }

    if ($error == "deactivate") {
        alert("Your 2fa successfuly deactivate.", "primary");
    }
    echo "</div>";
}

/*
 * Update the profile picture.
 * @author rizimore
 * @version 1.0.0 
 */
if(isset($_POST['profile'])) {
    $id             = $_SESSION['id'];
    $file_name      = $_FILES['image']['name'];
    $file_size      = $_FILES['image']['size'];
    $file_tmp       = $_FILES['image']['tmp_name'];
    $file_type      = $_FILES['image']['type'];
    $tmp            = explode('.', $file_name);
    $file_ext       = strtolower(end($tmp));
    $expensions     = array("jpeg", "jpg", "png", "gif");

    if(in_array($file_ext, $expensions) === false){
        header("Location: page.php?view=settings&error=type");   
    } elseif($file_size > 2097152){
        header("Location: page.php?view=settings&error=size");
    } else {
        move_uploaded_file($file_tmp, "assets/uploads/" . $file_name);
        $query = "UPDATE users SET profile='{$file_name}' WHERE id = $id";
        $run = mysqli_query($con, $query);
        if ($run) {
            header("Location: page.php?view=settings&error=none");
        }
    }
}

/*
 * Delete the account instead of doing delete deactivate the account.
 * @author rizimore
 * @version 1.0.0 
 */
if(isset($_POST['delete'])) {
    $id = $_SESSION['id'];
    $query = "UPDATE users SET active = 2 WHERE id = $id";
    $run = mysqli_query($con, $query);
    if($run) {
        header("Location: logout.php");
    }
}

/*
 * Get the data about the user.
 * @author rizimore
 * @version 1.0.0 
 */
$query = "SELECT * FROM users WHERE id = $id";
$run = mysqli_query($con, $query);
while ($row = mysqli_fetch_assoc($run)) {
    $profile    = $row['profile'];
    $name       = $row['name'];
    $email      = $row['email'];
    $address1   = $row['address1'];
    $address2   = $row['address2'];
    $city       = $row['city'];
    $postcode   = $row['postcode'];
    $country    = $row['country'];
}
?>
<div class="col-lg-4">
    <section class="box has-border-left-3">
        <div class="content-body">
           <div class="uprofile-image mt-30">
                <a data-toggle="modal" href="#image">
                    <img alt="<?php echo $name; ?>" src="<?php if(empty($profile) || $profile == "") { echo "assets/data/icons/default-avatar.png"; } else { echo "assets/uploads/".$profile; } ?>" class="img-responsive">
                </a>
            </div>
            <div class="uprofile-name">
                <h3><?php echo $name; ?></h3>
                <div class="modal fade col-xs-12" id="image" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog animated rubberBand">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Update Profile Picture</h4>
                            </div>
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="modal-body">                   
                                    <div class="avatar-img">
                                        <div class="avatar-img-wrapper">
                                            <img src="assets/data/icons/id-card.png" style="max-width:100px">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="formfield10">Upload Profile Picture</label>
                                            <span class="desc">"JPG, GIF or PNG Max size of 2MB"</span>
                                            <div class="controls">
                                                <input type="file" name="image">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-primary" type="submit" name="profile">Update Picture</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <p class="uprofile-title"><?php echo $email; ?></p>
            </div>
            <div class="uprofile-buttons">
                <a href="logout.php" class="btn btn-md btn-primary">Logout</a>
                <a class="btn btn-primary btn-md" data-toggle="modal" href="#delete">Delete Account</a>
                <div class="modal fade col-xs-12" id="delete" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog animated rubberBand">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Delete Account Confirmation</h4>
                            </div>
                            <div class="modal-body">
                                <p>Withdraw funds and close your Coinbase account - <b>this cannot be undone</b></p>
                            </div>
                            <div class="modal-footer">
                                <form action="" method="post">
                                    <button class="btn btn-danger" type="submit" name="delete">Delete Account</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<div class="col-lg-8">
	<?php include "templates/dashboard/pages/settings/profile.php"; ?>
    <?php include "templates/dashboard/pages/settings/password.php"; ?>
    <?php include "templates/dashboard/pages/settings/2fa.php"; ?>
</div>