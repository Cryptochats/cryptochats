<section id="main-content">
    <div class="wrapper main-wrapper row">

        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">
                    <h1 class="title">Users</h1>
                </div>
                <div class="pull-right hidden-xs">
                    <ol class="breadcrumb">
                        <li><a href="page.php?view=dashboard"><i class="fa fa-home"></i>Home</a></li>
                        <li class="active"><strong>Users Manegment</strong></li>
                    </ol>
                </div>
            </div>
        </div>

        <?php
		/*
		 * Update user personal information.
		 * @author rizimore
		 * @version 1.0.0 
		 */
		if (isset($_POST['update'])) {
			$user			= (int)$_POST['id'];
		    $name           = $_POST['name'];
		    $address1       = $_POST['address1'];
		    $address2       = $_POST['address2'];
		    $city           = $_POST['city'];
		    $postcode       = $_POST['postcode'];
		    $country        = $_POST['country'];
		    $dob            = "{$_POST['year']}-{$_POST['month']}-{$_POST['day']}";
		    $dob            = date("Y-m-d", strtotime($dob));
		    $status 		= (int)$_POST['status'];

		    $query = "UPDATE users SET name='{$name}', address1='{$address1}', address2='{$address2}', city='{$city}', postcode='{$postcode}', country='{$country}', dob='{$dob}', active=$status WHERE id = $user";
		    $run = mysqli_query($con, $query);
		    if ($run) {
		    	echo "<div class='col-xs-12'>";
		        alert("User profile successfuly updated.", "success");
		        echo "</div>";
		    }
		}
		/*
		 * Delete the user.
		 * @author rizimore
		 * @version 1.0.0 
		 */
		if (isset($_POST['delete'])) {
			$user = (int)$_POST['id'];
			$query = "DELETE FROM users WHERE id = $user";
			$run = mysqli_query($con, $query);
			if($run) {
				echo "<div class='col-xs-12'>";
		        alert("User successfuly deleted user the system.", "success");
		        echo "</div>";
			}
		}

		/*
		 * Create the user.
		 * @author rizimore
		 * @version 1.0.0 
		 */

		?>

        <div class="col-xs-12">
            <section class="box" style="border-left: 3px solid #e77512;">
                <header class="panel_header">
                    <h2 class="title pull-left">User Manegment</h2>
                    <button type="button" class="btn btn-primary pull-right" data-toggle="modal" href="#adduser"><i class="fa fa-plus"></i></button>
                    <div class="modal fade col-xs-12" id="adduser">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            	<form action="" method="post">
                            		<input type="hidden" name="user" value="<?php $id; ?>">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <h4 class="modal-title">Create New User</h4>
                                    </div>
                                    <div class="modal-body">
                                    	<div class="row">
				                            <div class="col-xs-12">
				                            	<div class="col-lg-6 no-pl">
				                                    <div class="form-group">
				                                        <label class="form-label">User ID</label>
				                                        <div class="controls">
				                                            <input type="number" class="form-control" name="id" placeholder="id" readonly>
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-lg-6 no-pr">
				                                    <div class="form-group">
				                                        <label class="form-label">Real Name</label>
				                                        <div class="controls">
				                                            <input type="text" class="form-control" name="name" placeholder="name">
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-lg-6 no-pl">
				                                    <div class="form-group">
				                                        <label class="form-label">Email</label>
				                                        <div class="controls">
				                                            <input type="email" class="form-control" name="email" placeholder="email">
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-lg-6 no-pr">
				                                    <div class="form-group">
				                                        <label class="form-label">Street address 1</label>
				                                        <div class="controls">
				                                            <input type="text" class="form-control" name="address1" placeholder="address 1">
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-lg-6 no-pl">
				                                    <div class="form-group">
				                                        <label class="form-label">Street address 2</label>
				                                        <div class="controls">
				                                            <input type="text" class="form-control" name="address2" placeholder="address 2">
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-lg-6 no-pr">
				                                    <div class="form-group">
				                                        <label class="form-label">City</label>
				                                        <div class="controls">
				                                            <input type="text" class="form-control" name="city" placeholder="city">
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-lg-6 no-pl">
				                                    <div class="form-group">
				                                        <label class="form-label">Postcode</label>
				                                        <div class="controls">
				                                            <input type="text" class="form-control" name="postcode" placeholder="postcode">
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-lg-6 no-pr">
				                                    <div class="form-group">
				                                        <label class="form-label">Country</label>
				                                        <div class="controls">
				                                            <input type="text" class="form-control" name="country" placeholder="country">
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="col-lg-6 no-pl">
				                                    <div class="form-group">
				                                        <label class="form-label">Date of birth</label>
				                                        <div class="row">
				                                            <div class="col-lg-4">
				                                                <div class="controls">
				                                                    <select name="day" class="form-control">
				                                                        <option value="1">1</option>
				                                                        <option value="2">2</option>
				                                                        <option value="3">3</option>
				                                                        <option value="4">4</option>
				                                                        <option value="5">5</option>
				                                                        <option value="6">6</option>
				                                                        <option value="7">7</option>
				                                                        <option value="8">8</option>
				                                                        <option value="9">9</option>
				                                                        <option value="10">10</option>
				                                                        <option value="11">11</option>
				                                                        <option value="12">12</option>
				                                                        <option value="13">13</option>
				                                                        <option value="14">14</option>
				                                                        <option value="15">15</option>
				                                                        <option value="16">16</option>
				                                                        <option value="17">17</option>
				                                                        <option value="18">18</option>
				                                                        <option value="19">19</option>
				                                                        <option value="20">20</option>
				                                                        <option value="21">21</option>
				                                                        <option value="22">22</option>
				                                                        <option value="23">23</option>
				                                                        <option value="24">24</option>
				                                                        <option value="25">25</option>
				                                                        <option value="26">26</option>
				                                                        <option value="27">27</option>
				                                                        <option value="28">28</option>
				                                                        <option value="29">29</option>
				                                                        <option value="30">30</option>
				                                                        <option value="31">31</option>
				                                                    </select>
				                                                </div>
				                                            </div>
				                                            <div class="col-lg-4">
				                                                <div class="controls">
				                                                    <select name="month" class="form-control">
				                                                        <option value="1">1</option>
				                                                        <option value="2">2</option>
				                                                        <option value="3">3</option>
				                                                        <option value="4">4</option>
				                                                        <option value="5">5</option>
				                                                        <option value="6">6</option>
				                                                        <option value="7">7</option>
				                                                        <option value="8">8</option>
				                                                        <option value="9">9</option>
				                                                        <option value="10">10</option>
				                                                        <option value="11">11</option>
				                                                        <option value="12">12</option></select>
				                                                </div>
				                                            </div>
				                                            <div class="col-lg-4">
				                                                <div class="controls">
				                                                    <select name="year" class="form-control">
				                                                        <option value="2015">2015</option>
				                                                        <option value="2014">2014</option>
				                                                        <option value="2013">2013</option>
				                                                        <option value="2012">2012</option>
				                                                        <option value="2011">2011</option>
				                                                        <option value="2010">2010</option>
				                                                        <option value="2009">2009</option>
				                                                        <option value="2008">2008</option>
				                                                        <option value="2007">2007</option>
				                                                        <option value="2006">2006</option>
				                                                        <option value="2005">2005</option>
				                                                        <option value="2004">2004</option>
				                                                        <option value="2003">2003</option>
				                                                        <option value="2002">2002</option>
				                                                        <option value="2001">2001</option>
				                                                        <option value="2000">2000</option>
				                                                        <option value="1999">1999</option>
				                                                        <option value="1998">1998</option>
				                                                        <option value="1997">1997</option>
				                                                        <option value="1996">1996</option>
				                                                        <option value="1995">1995</option>
				                                                        <option value="1994">1994</option>
				                                                        <option value="1993">1993</option>
				                                                        <option value="1992">1992</option>
				                                                        <option value="1991">1991</option>
				                                                        <option value="1990">1990</option>
				                                                        <option value="1989">1989</option>
				                                                        <option value="1988">1988</option>
				                                                        <option value="1987">1987</option>
				                                                        <option value="1986">1986</option>
				                                                        <option value="1985">1985</option>
				                                                        <option value="1984">1984</option>
				                                                        <option value="1983">1983</option>
				                                                        <option value="1982">1982</option>
				                                                        <option value="1981">1981</option>
				                                                        <option value="1980">1980</option>
				                                                        <option value="1979">1979</option>
				                                                        <option value="1978">1978</option>
				                                                        <option value="1977">1977</option>
				                                                        <option value="1976">1976</option>
				                                                        <option value="1975">1975</option>
				                                                        <option value="1974">1974</option>
				                                                        <option value="1973">1973</option>
				                                                        <option value="1972">1972</option>
				                                                        <option value="1971">1971</option>
				                                                        <option value="1970">1970</option>
				                                                        <option value="1969">1969</option>
				                                                        <option value="1968">1968</option>
				                                                        <option value="1967">1967</option>
				                                                        <option value="1966">1966</option>
				                                                        <option value="1965">1965</option>
				                                                        <option value="1964">1964</option>
				                                                        <option value="1963">1963</option>
				                                                        <option value="1962">1962</option>
				                                                        <option value="1961">1961</option>
				                                                        <option value="1960">1960</option>
				                                                        <option value="1959">1959</option>
				                                                        <option value="1958">1958</option>
				                                                        <option value="1957">1957</option>
				                                                        <option value="1956">1956</option>
				                                                        <option value="1955">1955</option>
				                                                        <option value="1954">1954</option>
				                                                        <option value="1953">1953</option>
				                                                        <option value="1952">1952</option>
				                                                        <option value="1951">1951</option>
				                                                        <option value="1950">1950</option>
				                                                        <option value="1949">1949</option>
				                                                        <option value="1948">1948</option>
				                                                        <option value="1947">1947</option>
				                                                        <option value="1946">1946</option>
				                                                        <option value="1945">1945</option>
				                                                        <option value="1944">1944</option>
				                                                        <option value="1943">1943</option>
				                                                        <option value="1942">1942</option>
				                                                        <option value="1941">1941</option>
				                                                        <option value="1940">1940</option>
				                                                        <option value="1939">1939</option>
				                                                        <option value="1938">1938</option>
				                                                        <option value="1937">1937</option>
				                                                        <option value="1936">1936</option>
				                                                        <option value="1935">1935</option>
				                                                        <option value="1934">1934</option>
				                                                        <option value="1933">1933</option>
				                                                        <option value="1932">1932</option>
				                                                        <option value="1931">1931</option>
				                                                        <option value="1930">1930</option>
				                                                        <option value="1929">1929</option>
				                                                        <option value="1928">1928</option>
				                                                        <option value="1927">1927</option>
				                                                        <option value="1926">1926</option>
				                                                        <option value="1925">1925</option>
				                                                        <option value="1924">1924</option>
				                                                        <option value="1923">1923</option>
				                                                        <option value="1922">1922</option>
				                                                        <option value="1921">1921</option>
				                                                        <option value="1920">1920</option>
				                                                        <option value="1919">1919</option>
				                                                        <option value="1918">1918</option>
				                                                        <option value="1917">1917</option>
				                                                        <option value="1916">1916</option>
				                                                        <option value="1915">1915</option>
				                                                        <option value="1914">1914</option>
				                                                        <option value="1913">1913</option>
				                                                        <option value="1912">1912</option>
				                                                        <option value="1911">1911</option>
				                                                        <option value="1910">1910</option>
				                                                        <option value="1909">1909</option>
				                                                        <option value="1908">1908</option>
				                                                        <option value="1907">1907</option>
				                                                        <option value="1906">1906</option>
				                                                        <option value="1905">1905</option>
				                                                        <option value="1904">1904</option>
				                                                        <option value="1903">1903</option>
				                                                        <option value="1902">1902</option>
				                                                        <option value="1901">1901</option>
				                                                        <option value="1900">1900</option>
				                                                        <option value="1899">1899</option>
				                                                        <option value="1898">1898</option>
				                                                    </select>
				                                                </div>
				                                            </div>
				                                        </div>
				                                    </div>
				                                </div> 
				                            </div>
				                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary" name="add">Create User</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </header>
                <div class="content-body">
                    <div class="row">
                        <div class="col-xs-12">
                        	<div class="table-responsive" data-pattern="priority-columns">
								<table id="table" class="table table-small-font no-mb" style="width:100%">
							        <thead>
							            <tr>
							                <th>Name</th>
							                <th>Email</th>
							                <th>Country</th>
							                <th>City</th>
							                <th>Active</th>
							                <th>Role</th>
							                <th>Action</th>
							            </tr>
							        </thead>
							        <tbody>
							        	<?php
							        	$query = "SELECT * FROM users";
							        	$run = mysqli_query($con, $query);
							        	while ($row = mysqli_fetch_assoc($run)) {
							        		$id 		= $row['id'];
							        		$name 		= $row['name'];
							        		$email 		= $row['email'];
							        		$country 	= $row['country'];
							        		$city 		= $row['city'];
							        		$active 	= $row['active'];
							        		$role 		= $row['role'];
							        		$address1	= $row['address1'];
							        		$address2 	= $row['address2'];
							        		$postcode 	= $row['postcode'];
							        		$timestamp 	= strtotime($row['dob']);
							        		$day 		= date('d', $timestamp);
							        		$month 		= date('m', $timestamp);
							        		$year 		= date('Y', $timestamp);
							        		$status 	= $row['active'];
							        	?>
							            <tr>
							                <td><?php echo $name; ?></td>
							                <td><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></td>
							                <td><?php echo $country; ?></td>
							                <td><?php echo $city; ?></td>
							                <td><?php if($active == 1) { echo "Active"; } else { echo "Pending"; } ?></td>
							                <td><?php if($role == "admin") { echo "Admin"; } else { echo "User"; } ?></td>
							                <td><a class="btn btn-primary btn-corner" data-toggle="modal" href="#user-<?php echo $id; ?>">edit</a></td>

							                <div class="modal fade col-xs-12" id="user-<?php echo $id; ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                    	<form action="" method="post">
                                                    		<input type="hidden" name="user" value="<?php $id; ?>">
	                                                        <div class="modal-header">
	                                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	                                                            <h4 class="modal-title">User Detail</h4>
	                                                        </div>
	                                                        <div class="modal-body">
	                                                        	<div class="row">
										                            <div class="col-xs-12">
										                            	<div class="col-lg-6 no-pl">
										                                    <div class="form-group">
										                                        <label class="form-label">User ID</label>
										                                        <div class="controls">
										                                            <input type="number" class="form-control" name="id" value="<?php echo $id; ?>" placeholder="id" readonly>
										                                        </div>
										                                    </div>
										                                </div>
										                                <div class="col-lg-6 no-pr">
										                                    <div class="form-group">
										                                        <label class="form-label">Real Name</label>
										                                        <div class="controls">
										                                            <input type="text" class="form-control" name="name" value="<?php echo $name; ?>" placeholder="name">
										                                        </div>
										                                    </div>
										                                </div>
										                                <div class="col-lg-6 no-pl">
										                                    <div class="form-group">
										                                        <label class="form-label">Email</label>
										                                        <div class="controls">
										                                            <input type="email" class="form-control" name="email" value="<?php echo $email; ?>" placeholder="email" disabled>
										                                        </div>
										                                    </div>
										                                </div>
										                                <div class="col-lg-6 no-pr">
										                                    <div class="form-group">
										                                        <label class="form-label">Street address 1</label>
										                                        <div class="controls">
										                                            <input type="text" class="form-control" name="address1" placeholder="address 1" value="<?php echo $address1; ?>">
										                                        </div>
										                                    </div>
										                                </div>
										                                <div class="col-lg-6 no-pl">
										                                    <div class="form-group">
										                                        <label class="form-label">Street address 2</label>
										                                        <div class="controls">
										                                            <input type="text" class="form-control" name="address2" placeholder="address 2" value="<?php echo $address2; ?>">
										                                        </div>
										                                    </div>
										                                </div>
										                                <div class="col-lg-6 no-pr">
										                                    <div class="form-group">
										                                        <label class="form-label">City</label>
										                                        <div class="controls">
										                                            <input type="text" class="form-control" name="city" placeholder="city" value="<?php echo $city; ?>">
										                                        </div>
										                                    </div>
										                                </div>
										                                <div class="col-lg-6 no-pl">
										                                    <div class="form-group">
										                                        <label class="form-label">Postcode</label>
										                                        <div class="controls">
										                                            <input type="text" class="form-control" name="postcode" placeholder="postcode" value="<?php echo $postcode; ?>">
										                                        </div>
										                                    </div>
										                                </div>
										                                <div class="col-lg-6 no-pr">
										                                    <div class="form-group">
										                                        <label class="form-label">Country</label>
										                                        <div class="controls">
										                                            <input type="text" class="form-control" name="country" placeholder="country" value="<?php echo $country; ?>">
										                                        </div>
										                                    </div>
										                                </div>
										                                <div class="col-lg-6 no-pl">
										                                    <div class="form-group">
										                                        <label class="form-label">Date of birth</label>
										                                        <div class="row">
										                                            <div class="col-lg-4">
										                                                <div class="controls">
										                                                    <select name="day" class="form-control">
										                                                        <?php
										                                                        if(empty($day) || $day == "") {
										                                                            echo "<option value=''>Day</option>";
										                                                        } else {
										                                                            echo "<option value='$day' selected>$day</option>";
										                                                        }
										                                                        ?>
										                                                        <option value="1">1</option>
										                                                        <option value="2">2</option>
										                                                        <option value="3">3</option>
										                                                        <option value="4">4</option>
										                                                        <option value="5">5</option>
										                                                        <option value="6">6</option>
										                                                        <option value="7">7</option>
										                                                        <option value="8">8</option>
										                                                        <option value="9">9</option>
										                                                        <option value="10">10</option>
										                                                        <option value="11">11</option>
										                                                        <option value="12">12</option>
										                                                        <option value="13">13</option>
										                                                        <option value="14">14</option>
										                                                        <option value="15">15</option>
										                                                        <option value="16">16</option>
										                                                        <option value="17">17</option>
										                                                        <option value="18">18</option>
										                                                        <option value="19">19</option>
										                                                        <option value="20">20</option>
										                                                        <option value="21">21</option>
										                                                        <option value="22">22</option>
										                                                        <option value="23">23</option>
										                                                        <option value="24">24</option>
										                                                        <option value="25">25</option>
										                                                        <option value="26">26</option>
										                                                        <option value="27">27</option>
										                                                        <option value="28">28</option>
										                                                        <option value="29">29</option>
										                                                        <option value="30">30</option>
										                                                        <option value="31">31</option>
										                                                    </select>
										                                                </div>
										                                            </div>
										                                            <div class="col-lg-4">
										                                                <div class="controls">
										                                                    <select name="month" class="form-control">
										                                                        <?php
										                                                        if(empty($year) || $year == "") {
										                                                            echo "<option value=''>Month</option>";
										                                                        } else {
										                                                            echo "<option value='$month' selected>$month</option>";
										                                                        }
										                                                        ?>
										                                                        <option value="1">1</option>
										                                                        <option value="2">2</option>
										                                                        <option value="3">3</option>
										                                                        <option value="4">4</option>
										                                                        <option value="5">5</option>
										                                                        <option value="6">6</option>
										                                                        <option value="7">7</option>
										                                                        <option value="8">8</option>
										                                                        <option value="9">9</option>
										                                                        <option value="10">10</option>
										                                                        <option value="11">11</option>
										                                                        <option value="12">12</option></select>
										                                                </div>
										                                            </div>
										                                            <div class="col-lg-4">
										                                                <div class="controls">
										                                                    <select name="year" class="form-control">
										                                                        <?php
										                                                        if(empty($year) || $year == "") {
										                                                            echo "<option value=''>Year</option>";
										                                                        } else {
										                                                            echo "<option value='$year' selected>$year</option>";
										                                                        }
										                                                        ?>
										                                                        <option value="2015">2015</option>
										                                                        <option value="2014">2014</option>
										                                                        <option value="2013">2013</option>
										                                                        <option value="2012">2012</option>
										                                                        <option value="2011">2011</option>
										                                                        <option value="2010">2010</option>
										                                                        <option value="2009">2009</option>
										                                                        <option value="2008">2008</option>
										                                                        <option value="2007">2007</option>
										                                                        <option value="2006">2006</option>
										                                                        <option value="2005">2005</option>
										                                                        <option value="2004">2004</option>
										                                                        <option value="2003">2003</option>
										                                                        <option value="2002">2002</option>
										                                                        <option value="2001">2001</option>
										                                                        <option value="2000">2000</option>
										                                                        <option value="1999">1999</option>
										                                                        <option value="1998">1998</option>
										                                                        <option value="1997">1997</option>
										                                                        <option value="1996">1996</option>
										                                                        <option value="1995">1995</option>
										                                                        <option value="1994">1994</option>
										                                                        <option value="1993">1993</option>
										                                                        <option value="1992">1992</option>
										                                                        <option value="1991">1991</option>
										                                                        <option value="1990">1990</option>
										                                                        <option value="1989">1989</option>
										                                                        <option value="1988">1988</option>
										                                                        <option value="1987">1987</option>
										                                                        <option value="1986">1986</option>
										                                                        <option value="1985">1985</option>
										                                                        <option value="1984">1984</option>
										                                                        <option value="1983">1983</option>
										                                                        <option value="1982">1982</option>
										                                                        <option value="1981">1981</option>
										                                                        <option value="1980">1980</option>
										                                                        <option value="1979">1979</option>
										                                                        <option value="1978">1978</option>
										                                                        <option value="1977">1977</option>
										                                                        <option value="1976">1976</option>
										                                                        <option value="1975">1975</option>
										                                                        <option value="1974">1974</option>
										                                                        <option value="1973">1973</option>
										                                                        <option value="1972">1972</option>
										                                                        <option value="1971">1971</option>
										                                                        <option value="1970">1970</option>
										                                                        <option value="1969">1969</option>
										                                                        <option value="1968">1968</option>
										                                                        <option value="1967">1967</option>
										                                                        <option value="1966">1966</option>
										                                                        <option value="1965">1965</option>
										                                                        <option value="1964">1964</option>
										                                                        <option value="1963">1963</option>
										                                                        <option value="1962">1962</option>
										                                                        <option value="1961">1961</option>
										                                                        <option value="1960">1960</option>
										                                                        <option value="1959">1959</option>
										                                                        <option value="1958">1958</option>
										                                                        <option value="1957">1957</option>
										                                                        <option value="1956">1956</option>
										                                                        <option value="1955">1955</option>
										                                                        <option value="1954">1954</option>
										                                                        <option value="1953">1953</option>
										                                                        <option value="1952">1952</option>
										                                                        <option value="1951">1951</option>
										                                                        <option value="1950">1950</option>
										                                                        <option value="1949">1949</option>
										                                                        <option value="1948">1948</option>
										                                                        <option value="1947">1947</option>
										                                                        <option value="1946">1946</option>
										                                                        <option value="1945">1945</option>
										                                                        <option value="1944">1944</option>
										                                                        <option value="1943">1943</option>
										                                                        <option value="1942">1942</option>
										                                                        <option value="1941">1941</option>
										                                                        <option value="1940">1940</option>
										                                                        <option value="1939">1939</option>
										                                                        <option value="1938">1938</option>
										                                                        <option value="1937">1937</option>
										                                                        <option value="1936">1936</option>
										                                                        <option value="1935">1935</option>
										                                                        <option value="1934">1934</option>
										                                                        <option value="1933">1933</option>
										                                                        <option value="1932">1932</option>
										                                                        <option value="1931">1931</option>
										                                                        <option value="1930">1930</option>
										                                                        <option value="1929">1929</option>
										                                                        <option value="1928">1928</option>
										                                                        <option value="1927">1927</option>
										                                                        <option value="1926">1926</option>
										                                                        <option value="1925">1925</option>
										                                                        <option value="1924">1924</option>
										                                                        <option value="1923">1923</option>
										                                                        <option value="1922">1922</option>
										                                                        <option value="1921">1921</option>
										                                                        <option value="1920">1920</option>
										                                                        <option value="1919">1919</option>
										                                                        <option value="1918">1918</option>
										                                                        <option value="1917">1917</option>
										                                                        <option value="1916">1916</option>
										                                                        <option value="1915">1915</option>
										                                                        <option value="1914">1914</option>
										                                                        <option value="1913">1913</option>
										                                                        <option value="1912">1912</option>
										                                                        <option value="1911">1911</option>
										                                                        <option value="1910">1910</option>
										                                                        <option value="1909">1909</option>
										                                                        <option value="1908">1908</option>
										                                                        <option value="1907">1907</option>
										                                                        <option value="1906">1906</option>
										                                                        <option value="1905">1905</option>
										                                                        <option value="1904">1904</option>
										                                                        <option value="1903">1903</option>
										                                                        <option value="1902">1902</option>
										                                                        <option value="1901">1901</option>
										                                                        <option value="1900">1900</option>
										                                                        <option value="1899">1899</option>
										                                                        <option value="1898">1898</option>
										                                                    </select>
										                                                </div>
										                                            </div>
										                                        </div>
										                                    </div>
										                                </div>
										                                <div class="col-lg-6 no-pr">
										                                    <div class="form-group">
										                                        <label class="form-label">Status</label>
										                                        <div class="controls">
										                                            <select name="status" class="form-control">
								                                                        <?php
								                                                        if($status == 1) {
								                                                            echo '<option value="1" selected>Active</option>';
								                                                            echo '<option value="0">Deactive</option>';
								                                                        } else {
								                                                            echo '<option value="0" selected>Deactive</option>';
								                                                            echo '<option value="1">Active</option>';
								                                                        }
								                                                        ?>
								                                                    </select>
										                                        </div>
										                                    </div>
										                                </div>  
										                            </div>
										                        </div>
	                                                        </div>
	                                                        <div class="modal-footer">
	                                                            <button type="submit" class="btn btn-primary" name="update">Update</button>
	                                                            <button type="submit" class="btn btn-danger" name="delete" onclick="confirm('Do you really want to delete the user?')">Delete</button>
	                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	                                                        </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>

							            </tr>
							            <?php } ?>
							        </tbody>
							    </table>
							</div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        
        <div class="clearfix"></div>

    </div>
</section>

<script>
	function myFunction() {
	    confirm("Press a button!");
	}
</script>
</script>