<section id="main-content">
    <div class="wrapper main-wrapper row">

        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">
                    <h1 class="title">Cryptochats</h1>
                </div>
            </div>
        </div>
		
		<div class="col-xs-12">
        <?php
        if(isset($_POST['submit'])) {
        	$saleprice 		= $_POST['saleprice'];
        	$totalsupply 	= $_POST['totalsupply'];
        	$softcap 		= $_POST['softcap'];
        	$hardcap 		= $_POST['hardcap'];
        	$forsale 		= $_POST['forsale'];
        	$general 		= $_POST['general'];
        	$research 		= $_POST['research'];
        	$ecosystem 		= $_POST['ecosystem'];
        	$marketing 		= $_POST['marketing'];
        	$partnership 	= $_POST['partnership'];
        	$team 			= $_POST['team'];

        	$query = "UPDATE tokens SET saleprice='{$saleprice}', totalsupply=$totalsupply, softcap=$softcap, hardcap=$hardcap, forsale='{$forsale}', general=$general, research=$research, ecosystem=$ecosystem, marketing=$marketing, partnership=$partnership, team=$team WHERE symbol = 'CCX'";
        	$run = mysqli_query($con, $query);
        	if($run) {
        		alert("Your infromation update successfully. Now update on <a href='https://etherscan.io/tokenupdate' target='_blank'>etherscan</a>.", "primary");
        	}
        }
        ?>
		</div>

        <div class="col-xs-12">
        	<section class="box has-border-left-3">
			    <header class="panel_header"><h2 class="title pull-left">Update Token</h2></header>
			    <div class="content-body">    
			        <div class="row">
			            <div class="form-container">
			                <form action="" method="post">

			                	<?php
			                	$query = "SELECT * FROM tokens WHERE id = 1";
			                	$run = mysqli_query($con, $query);
			                	while ($row = mysqli_fetch_assoc($run)) {
			                		$name  			= $row['name'];
			                		$symbol 		= $row['symbol'];
			                		$saleprice 		= $row['saleprice'];
			                		$totalsupply 	= $row['totalsupply'];
			                		$softcap 		= $row['softcap'];
			                		$hardcap 		= $row['hardcap'];
			                		$forsale 		= $row['forsale'];
			                		$general 		= $row['general'];
			                		$research 		= $row['research'];
			                		$ecosystem 		= $row['ecosystem'];
			                		$marketing 		= $row['marketing'];
			                		$partnership 	= $row['partnership'];
			                		$team 			= $row['team'];
			                	?>

			                    <div class="row">
			                        <div class="col-xs-12">
			                            <div class="col-lg-4 no-pl">
			                                <div class="form-group">
			                                    <label class="form-label" for="name">Name</label>
			                                    <div class="controls">
			                                        <input type="text" class="form-control" name="name" id="name" required value="<?php echo $name; ?>" disabled="disabled">
			                                    </div>
			                                </div>
			                            </div>
			                            <div class="col-lg-4 no-pr">
			                                <div class="form-group">
			                                    <label class="form-label" for="symbol">Token Symbol</label>
			                                    <div class="controls">
			                                        <input type="text" class="form-control" name="symbol" id="symbol" required value="<?php echo $symbol; ?>" disabled="disabled">
			                                    </div>
			                                </div>
			                            </div>
			                            <div class="col-lg-4 no-pr">
			                                <div class="form-group">
			                                	<label class="form-label" for="saleprice">Sale Price</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">ETH</span>
				                                    <div class="controls">
				                                        <input type="text" class="form-control" name="saleprice" id="saleprice" required value="<?php echo $saleprice; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                        </div>

									<div class="col-xs-12">
										<div class="col-lg-4 no-pl">
			                                <div class="form-group">
			                                	<label class="form-label" for="totalsupply">Total Supply</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">CCX</span>
				                                    <div class="controls">
				                                        <input type="number" class="form-control" name="totalsupply" id="totalsupply" value="<?php echo $totalsupply; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                            <div class="col-lg-4 no-pr">
			                                <div class="form-group">
			                                	<label class="form-label" for="softcap">Soft Cap</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">USD</span>
				                                    <div class="controls">
				                                        <input type="number" class="form-control" name="softcap" id="softcap" value="<?php echo $softcap; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                            <div class="col-lg-4 no-pr">
			                                <div class="form-group">
			                                	<label class="form-label" for="hardcap">Hard Cap</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">USD</span>
				                                    <div class="controls">
				                                        <input type="number" class="form-control" name="hardcap" id="hardcap" value="<?php echo $hardcap; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                        </div>

			                        <div class="col-xs-12">
										<div class="col-lg-4 no-pl">
			                                <div class="form-group">
			                                	<label class="form-label" for="forsale">Token for Sale</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon"><?php echo $symbol; ?></span>
				                                    <div class="controls">
				                                        <input type="text" class="form-control" name="forsale" id="forsale" value="<?php echo $forsale; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                        </div>
									
									<div class="col-xs-12">
			                        	<br><br>
			                    	</div>

			                        <div class="col-xs-12">
										<div class="col-lg-4 no-pl">
			                                <div class="form-group">
			                                	<label class="form-label" for="general">General & Legal, Administrative</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">%</span>
				                                    <div class="controls">
				                                        <input type="number" class="form-control" name="general" id="general" value="<?php echo $general; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                            <div class="col-lg-4 no-pr">
			                                <div class="form-group">
			                                	<label class="form-label" for="research">Research & Development</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">%</span>
				                                    <div class="controls">
				                                        <input type="number" class="form-control" name="research" id="research" value="<?php echo $research; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                            <div class="col-lg-4 no-pr">
			                                <div class="form-group">
			                                	<label class="form-label" for="ecosystem">Ecosystem</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">%</span>
				                                    <div class="controls">
				                                        <input type="number" class="form-control" name="ecosystem" id="ecosystem" value="<?php echo $ecosystem; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                        </div>

			                        <div class="col-xs-12">
										<div class="col-lg-4 no-pl">
			                                <div class="form-group">
			                                	<label class="form-label" for="marketing">Marketing & Promotion</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">%</span>
				                                    <div class="controls">
				                                        <input type="number" class="form-control" name="marketing" id="marketing" value="<?php echo $marketing; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                            <div class="col-lg-4 no-pr">
			                                <div class="form-group">
			                                	<label class="form-label" for="partnership">Partnership</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">%</span>
				                                    <div class="controls">
				                                        <input type="number" class="form-control" name="partnership" id="partnership" value="<?php echo $partnership; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                            <div class="col-lg-4 no-pr">
			                                <div class="form-group">
			                                	<label class="form-label" for="team">Team</label>
			                                	<div class="input-group primary">
			                                		<span class="input-group-addon">%</span>
				                                    <div class="controls">
				                                        <input type="number" class="form-control" name="team" id="team" value="<?php echo $team; ?>">
				                                    </div>
			                                	</div>
			                                </div>
			                            </div>
			                        </div>

			                        <div class="col-xs-12">
				                        <div class="pull-left">
			                                <h4><i class="fa fa-info-circle color-primary complete f-s-14"></i><small>You can edit token here but for permanet modification you need to submit application on <a href="https://etherscan.io/tokenupdate" target="_blank">etherscan</a>.</small></h4>
			                            </div>
			                            <div class="pull-right">
			                                <button type="submit" class="btn btn-primary btn-corner" name="submit">Update Token</button>
			                            </div>
		                        	</div>
			                    </div>

			                    <?php } ?>

			                </form>
			            </div>
			        </div>
				</div>
			</section>
        </div>

    </div>
</section>