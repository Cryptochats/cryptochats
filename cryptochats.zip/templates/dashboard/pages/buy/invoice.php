<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<section id="main-content">
    <div class="wrapper main-wrapper row">

        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">
                    <h1 class="title">Invoice Detail</h1>
                </div>
            </div>
        </div>
    
        <div class="clearfix"></div>

        <div class="col-lg-6">
            <section class="box has-border-left-3">
                <header class="panel_header">
                    <h2 class="title pull-left">Invoice ID: <b><?php echo $_GET['id']; ?></b></h2>
                </header>
                <div class="content-body">   
                    <div class="row">
                        <?php
                        $id = $_GET['id'];
                        $query = "SELECT * FROM transactions WHERE order_id = $id";
                        $run = mysqli_query($con, $query);
                        while ($row = mysqli_fetch_assoc($run)) {
                            $order      = $row['id'];
                            $address    = strtolower($row['address']);
                            $datetime   = $row['date'];
                            $status     = $row['status'];
                            $token      = $row['token'];
                            $amount     = $row['amount'];
                        ?>
                        <div class="col-md-4">
                            <img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=<?php echo $address; ?>&choe=UTF-8" class="img-responsive" style="border: 3px solid #e77512">
                        </div>
                        <div class="col-md-8">
                            <?php if($status != 2) { ?>
                                <p>Send exactly <b><?php echo $amount; ?> ETH</b> to address:</p>
                            <?php } else { ?>
                                <p>Your transaction is complete. Thanks for buying the token.</p>
                            <?php } ?>
                            <p><input type="text" readonly="readonly" value="<?php echo $address; ?>" class="form-control"></p>
                            <p><b>Status:</b> 
                                <?php 
                                if($status == 0) { echo '<span class="status-cancelled">cancelled</span>'; }
                                if($status == 1) { echo '<span class="status-pending" style="border: 1px solid #e77512;">pending</span>'; }
                                if($status == 2) { echo '<span class="status-complete">complete</span>'; }
                                ?>
                            </p>
                            <div id="check"></div>
                            <p><b>Token Purchased:</b> <?php echo $token; ?> CCX</p>
                        </div>

                        <?php
                        /*
                         * Check we receiev the payment or not.
                         * @author rizimore
                         * @version 1.0.0 
                         */
                        if($status != 2) {
                            $order_id   = $_GET['id'];
                            $url        = "http://api.ethplorer.io/getAddressTransactions/$address?apiKey=freekey";

                            $file = file_get_contents($url);
                            $data = json_decode($file, true);
                            foreach ($data as $transaction) {
                                $to = (string)$transaction['to'];
                                if($address == $to) {
                                    $amount = (string)$transaction['value'];
                                    $query = "SELECT * FROM transactions WHERE order_id = $order_id";
                                    $run = mysqli_query($con, $query);
                                    while ($row = mysqli_fetch_assoc($run)) {
                                        $given_amount = (string)$row['amount'];
                                        if($given_amount == $amount) {
                                            $query_update = "UPDATE transactions SET status = 2 WHERE order_id = $order_id";
                                            $run_update = mysqli_query($con, $query_update);
                                            if($run_update) {
                                                $user = $_SESSION['id'];
                                                $query_balance = "SELECT * FROM users WHERE id = $user";
                                                $run_balance = mysqli_query($con, $query_balance);
                                                while ($row_balance = mysqli_fetch_assoc($run_balance)) {
                                                    $balance = (int)$row_balance['balance'];
                                                    $newbalance = (int)$token;
                                                    $totalbalance = $balance + $newbalance;
                                                    $totalbalance = (string)$totalbalance;
                                                    $query_balance_update = "UPDATE users SET balance = '{$totalbalance}' WHERE id = $user";
                                                    $run_balance_update = mysqli_query($con, $query_balance_update);
                                                }
                                            }
                                        } else {
                                            echo "<div class='col-md-8'><b style='color: #e77512;'>Warning: </b>You send <b>$amount</b> ETH instead of <b>$given_amount</b> ETH.</div>";
                                        }
                                    }
                                }
                            }
                        }
                        ?>

                        <?php } ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
</section>

<script type="text/javascript">
    setTimeout(function() { location.reload(); }, 5000);
</script>