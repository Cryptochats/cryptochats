<section id="main-content">
    <div class="wrapper main-wrapper row">

        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">
                    <h1 class="title">Buy Tokens</h1>
                </div>
            </div>
        </div>
    
        <div class="clearfix"></div>

        <div class="col-lg-6">
            <section class="box has-border-left-3">
                <header class="panel_header">
                    <h2 class="title pull-left">Cryptochats Tokens</h2>
                </header>
                <div class="content-body">   
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="transfer-wraper">
                                <div class="form-group no-mb">
                                    <form action="" method="post">
                                        <div class="col-lg-5 no-pl">
                                            <div class="input-group">
                                                <input type="number" class="form-control" placeholder="amount of tokens to purchase" oninput="updateTokenRecieved()" name="amount" id="amount">
                                                <span class="input-group-addon">CCX</span>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <div class="exchange-img-wrapper">
                                                <img src="assets/data/icons/exchange-arrows.png" class="mt-5 center-block" style="width:25px">
                                            </div>
                                        </div>
                                        <div class="col-lg-5 no-pr">
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="total eth price" id="total" disabled>
                                                <span class="input-group-addon">ETH</span>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-lg mt-20 has-gradient-to-right-bottom" style="width:100%" name="submit">
                                            Buy Tokens
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <?php
        if(isset($_POST['submit'])) {

            $user           = (int)$_SESSION['id'];
            $token          = (int)$_POST['amount'];
            $orderId        = (int)rand(1, 100000);
            $apiSecret      = 'secb41bd1dc0736ac2448c37f8866345dcf';
            $callbackUrl    = 'https://40649878.ngrok.io/wallet/callback.php?id='.$orderId;

            $url = sprintf('https://api.paybear.io/v2/eth/payment/%s?token=%s', urlencode($callbackUrl), $apiSecret);
            if ($response = file_get_contents($url)) {
                $response = json_decode($response);
                if (isset($response->data->address)) {

                    $address = $response->data->address;
                    $invoice = $response->data->invoice;

                    $query = "SELECT * FROM tokens WHERE symbol = 'CCX'";
                    $run = mysqli_query($con, $query);
                    while($row = mysqli_fetch_assoc($run)) {

                        $price = $row['saleprice'];
                        $amount = $token * $price;
                        $query = "INSERT INTO transactions(order_id, address, invoice, token, user, amount, action) VALUES($orderId, '{$address}', '{$invoice}', $token, $user, '{$amount}', 'plus')";
                        $run = mysqli_query($con, $query);
                        if($run) {
                            header("Location: page.php?view=buy&id=".$orderId);
                        }
                        
                    }
                }
            }
        }
        ?>

        <div class="col-lg-1 hidden-md mt-15">
            <div class="arrow-container text-center">
                <i class="fa fa-arrow-right mt-100 pt-30"></i>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="col-xs-12 mt-20">
                <h4 class="mb text-center bold">YOU ARE BUYING THE FOLLOWING</h4>
            </div>
            <div class="clearfix"></div>
            <section class="box has-border-left-3">
                <div class="content-body">    
                    <div class="row">
                        <div class="col-xs-12 mt-20 mb-30">
                            <?php
                            $query = "SELECT * FROM tokens WHERE symbol = 'CCX'";
                            $run = mysqli_query($con, $query);
                            while($row = mysqli_fetch_assoc($run)) {
                                $price = $row['saleprice'];
                            ?>
                                <h2 class="mb text-center bold"><span id="saleprice"><?php echo $price; ?></span> ETH</h2>
                                <small class="text-center f-s-14" style="display:block; font-weight:600;">price per token</small>
                            <?php } ?>
                        </div>
                        <div class="clearfix"></div>
                        <div class="deal-wrapper">
                            <ul class="dropdown-menu-list list-unstyled no-mb">
                                <li>
                                    <div class="notice-icon">
                                        <i class="fa fa-credit-card"></i>
                                    </div>
                                    <div>
                                        <span class="name">
                                            <strong>ETHEREUM</strong>
                                            <span class="time small">Payment method - <b>for right now there is only 1 payment method</b></span>
                                        </span>
                                    </div>
                                </li>
                                <li>
                                    <div class="notice-icon">
                                        <i class="fa fa-dollar"></i>
                                    </div>
                                    <div>
                                        <span class="name">
                                            <strong id="totalbill">0 ETH</strong>
                                            <span class="time small">Total Bill</span>
                                        </span>
                                    </div>
                                </li>
                                <li>
                                    <div class="notice-icon">
                                        <i class="fa fa-money"></i>
                                    </div>
                                    <div>
                                        <span class="name">
                                            <strong id="updateTokenRecieved">0</strong>
                                            <span class="time small">Tokens recieved</span>
                                        </span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <div class="clearfix"></div>

    </div>
</section>

<script>
    function updateTokenRecieved() {
        var x = document.getElementById("amount").value;
        var y = document.getElementById("saleprice").innerHTML;
        var z = x * y;
        document.getElementById("updateTokenRecieved").innerHTML = x;
        document.getElementById("total").value = z;
        document.getElementById("totalbill").innerHTML = z + " ETH";
    }
</script>