<div id="main-content">
    <section class="wrapper main-wrapper row">

        <div class="col-xs-12">
            <div class="page-title">
				<div class="pull-left">
                    <h1 class="title">Settings</h1>
                </div>
            </div>
        </div>

        <?php include "templates/dashboard/pages/settings/template.php"; ?>
        
    </section>
</div>