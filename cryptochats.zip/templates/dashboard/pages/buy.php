<?php

/*
* Dsiplaying the invoice and buy page.
* @author rizimore
* @version 1.0.0 
*/
if(isset($_GET['id'])) {
    include 'templates/dashboard/pages/buy/invoice.php';
} else {
    include 'templates/dashboard/pages/buy/buy.php';
}

?>